 <!-- Modal Login-->
<div class="modal fade" id="myModalSignIn" role="dialog">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h4>LOGIN</h4>             
            </div>
            <!--End Modal Header-->

            <div class="modal-body">
                <form role="form">
                    <div class="form-group">
                        <input type="text" class="form-control" id="usrname" placeholder="Enter Email">
                    </div>
                    <!--Username-->
                    <div class="form-group">
                        <input type="password" class="form-control" id="psw" placeholder="Enter Password">
                    </div>
                    <!--Password-->
                    <button type="submit" class="btn btn-default btn-block">Login</button>
                </form>
            </div>
            <!--End Modal Body-->
        </div>
        <!--End Modal Content-->
    </div>
    <!--End Modal Dialog-->
</div>
<!--End Modal-->